# 14-Day Excel Data Analytics Repository

This repository is a day-wise Excel practice track based on the uploaded **Unit1&2.pdf**.

## Day Plan
1. Data Analytics Fundamentals
2. Excel Data Structure & Tables
3. Formula Fundamentals
4. Logical Functions & Conditional Formatting
5. Text & Date Cleaning
6. SUMIF / SUMIFS / COUNTIF / COUNTIFS
7. Lookup Functions
8. PivotTable Analysis
9. Charts & PivotCharts
10. What-If Analysis & Goal Seek
11. Scenario Manager & Data Tables
12. Solver Optimization
13. Power Query Basics
14. Professional Excel Dashboard — Capstone

## GitHub structure
```text
14-Day-Excel-Data-Analytics/
├── Day01_Data_Analytics_Fundamentals.xlsx
├── Day02_Excel_Data_Structure.xlsx
├── Day03_Formula_Fundamentals.xlsx
├── Day04_Logical_Functions_Conditional_Formatting.xlsx
├── Day05_Text_Date_Cleaning.xlsx
├── Day06_SUMIF_SUMIFS_COUNTIF.xlsx
├── Day07_Lookup_Functions.xlsx
├── Day08_PivotTable_Analysis.xlsx
├── Day09_Charts_and_PivotCharts.xlsx
├── Day10_WhatIf_GoalSeek.xlsx
├── Day11_Scenarios_DataTables.xlsx
├── Day12_Solver_Optimization.xlsx
├── Day13_Power_Query_Basics.xlsx
└── Day14_Professional_Excel_Dashboard.xlsx
```

Each workbook contains a README sheet plus the practice data/model required for that day.

**Source:** user-provided Unit1&2.pdf. The workbooks keep the terminology and sequence of the source, while the extended datasets are synthetic practice data derived from the source's sales-data structure.